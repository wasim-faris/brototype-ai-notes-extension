const s={gemini:{label:"Google Gemini",adapter:"gemini",defaultBaseUrl:"https://generativelanguage.googleapis.com/v1beta",defaultModel:"gemini-3.6-flash",modelSuggestions:["gemini-3.6-flash","gemini-flash-latest","gemini-3.5-flash","gemini-flash-lite-latest","gemini-pro-latest"],keyHint:"AIza… or AQ.…",keyUrl:"https://aistudio.google.com/app/apikey",note:"Has a free tier with no card required — the easiest place to start. Model names here are retired fairly often; if one stops working the error will quote Google's replacement.",capabilities:{structuredOutput:"response_schema",systemPrompt:!0,maxOutputTokens:65536},requestsPerMinute:10},openai:{label:"OpenAI",adapter:"openai-compatible",defaultBaseUrl:"https://api.openai.com/v1",defaultModel:"gpt-4.1-mini",modelSuggestions:["gpt-4.1-mini","gpt-4.1","gpt-4o-mini","gpt-4o"],keyHint:"sk-…",keyUrl:"https://platform.openai.com/api-keys",note:"Needs a paid API account. A ChatGPT Plus/Go subscription does NOT include API access.",capabilities:{structuredOutput:"json_schema",systemPrompt:!0,maxOutputTokens:32768},requestsPerMinute:60},claude:{label:"Anthropic Claude",adapter:"claude",defaultBaseUrl:"https://api.anthropic.com/v1",defaultModel:"claude-sonnet-5",modelSuggestions:["claude-sonnet-5","claude-opus-5","claude-haiku-4-5-20251001"],keyHint:"sk-ant-…",keyUrl:"https://console.anthropic.com/settings/keys",note:"Needs a paid API account. A Claude.ai subscription does NOT include API access.",capabilities:{structuredOutput:"tool",systemPrompt:!0,maxOutputTokens:32e3},requestsPerMinute:50},grok:{label:"xAI Grok",adapter:"openai-compatible",defaultBaseUrl:"https://api.x.ai/v1",defaultModel:"grok-4-fast",modelSuggestions:["grok-4-fast","grok-4","grok-3-mini","grok-3"],keyHint:"xai-…",keyUrl:"https://console.x.ai",note:"No free tier: a new xAI team must buy credits at console.x.ai before any request works, even with a valid key.",capabilities:{structuredOutput:"json_schema",systemPrompt:!0,maxOutputTokens:32768},requestsPerMinute:60},openrouter:{label:"OpenRouter",adapter:"openai-compatible",defaultBaseUrl:"https://openrouter.ai/api/v1",defaultModel:"nvidia/nemotron-3-super-120b-a12b:free",modelSuggestions:["nvidia/nemotron-3-super-120b-a12b:free","google/gemma-4-31b-it:free","google/gemma-4-26b-a4b-it:free","z-ai/glm-5.2:free","minimax/minimax-m2.7:free"],keyHint:"sk-or-v1-…",keyUrl:"https://openrouter.ai/settings/keys",note:'One key, hundreds of models. Models ending in ":free" cost nothing but are rate-limited and shared, so a big run may need retries. Any model id from openrouter.ai/models works here.',capabilities:{structuredOutput:"auto",systemPrompt:!0,maxOutputTokens:16384},requestsPerMinute:8},custom:{label:"Custom / OpenAI-compatible",adapter:"openai-compatible",defaultBaseUrl:"",defaultModel:"",modelSuggestions:[],keyHint:"optional for local servers",baseUrlRequired:!0,keyOptional:!0,note:"Any service speaking POST /chat/completions — DeepSeek, Groq, Together, LM Studio, or a local Ollama server (port 11434, path /v1). OpenRouter has its own entry above.",capabilities:{structuredOutput:"auto",systemPrompt:!0,maxOutputTokens:16384},requestsPerMinute:30}},p=Object.keys(s),P=e=>s[e]||null,E=()=>p.map(e=>({id:e,label:s[e].label})),d=e=>{var t;return{apiKey:"",model:((t=s[e])==null?void 0:t.defaultModel)||"",baseUrl:""}},m="https://brototype-ai-notes-backend.onrender.com",U=!1,i=e=>{const t=String(e||"").trim();return!t||!/^https:\/\//i.test(t)?"":t},M=e=>i(e==null?void 0:e.notionOAuthBackendUrl)||m,y=["default","custom"],k=4e3,c=`SHORT + SIMPLE + BEGINNER-FRIENDLY + EASY TO VISUALIZE + COMPLETE ENOUGH TO STUDY.
Not: long + everything about the topic + unnecessary theory. Teach the MINIMUM a beginner needs to clearly understand the topic.

Explain like a knowledgeable friend sitting next to a beginner, not like a textbook.

Language:
- Very simple English. Short sentences. No long paragraphs.
- Explain a difficult word the moment you use it, in simple words. For example:
  "Memoization means remembering a previous result so we don't calculate it again unnecessarily."
- Say WHY something is used, not only what it is - but in a line, not an essay.

How much to write - decide from the topic, never from a template:
- A simple theory topic gets a simple answer. "What is Vite?" is: what it is, and a short list of what it helps you do. Then STOP. No history, no internals, no analogy, no mistakes.
- A concept with code gets what a beginner needs to use it: what it is, a one-line real-world example, basic syntax, a small example. A comparison table when two things are easily confused (useState vs useContext). A common mistake only when beginners really make it.
- Never add a section that does not help understanding of THIS topic.

Main parts / stages - only when the topic really has them:
- If a topic has internal steps, stages or parts a beginner MUST know (creating → providing → consuming for useContext; request → route → controller → response for an API), give them as ONE short list: each part is one line, bold name, dash, the key idea.
- Three parts? Show three. Five? Show five. No real parts? No such section - never invent stages to fill space.
- One line each. Never a paragraph per stage.

Real-life example - make it EASY TO IMAGINE, not merely short:
- Use a simple, familiar, everyday situation the student can picture at once: a wardrobe, a cashier, a noticeboard, a queue at a shop.
- One line is often enough ("Theme switching: light mode and dark mode."). But when a slightly bigger picture makes the idea click, use 3-6 short lines - a tiny scene, simple objects, emojis where they help (👕 shirts, 👖 pants, 🧦 socks - one pile vs sorted sections = a data structure).
- Never a long story, never unnecessary explanation. Stop as soon as the idea is clear.

Code:
- Small first. Explain the important variables and what happens, step by step, only when it is not obvious.
- Show the complete working code only when the small example is not enough to actually use the concept.

Style reference for the level of detail (a reference, not a template):

  What is Vite?
  Vite is a frontend build tool and development server.
  It helps: create a React project · start a local dev server · reload changes quickly · build for production.

  What is useContext?
  useContext lets a component get shared data without passing props through every component.
  Main parts of useContext:
    **Creating** — createContext() creates the context that holds shared data.
    **Providing** — Provider gives the shared data to components.
    **Consuming** — useContext() lets a component read the shared data.
  Real-world example: a dark/light theme shared by many components.
  Simple example: const theme = useContext(ThemeContext);

Reviewer questions:
- Five practical questions a Brototype reviewer could realistically ask about this task.
- They test understanding, not memorisation ("why would you choose X here?" rather than "what is X?").
- Each answer is short and something the student can say out loud in a review.`,f=Object.freeze({mode:"default",customPrompt:""});function b(e){return String(e??"").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,"").replace(/\r\n?/g,`
`).trim().slice(0,k)}function C(e){const t=y.includes(e==null?void 0:e.mode)?e.mode:"default",a=b(e==null?void 0:e.customPrompt);return t==="custom"&&a?{mode:"custom",text:a,source:"custom"}:t==="custom"&&!a?{mode:"default",text:c,source:"default (custom prompt was empty)"}:{mode:"default",text:c,source:"default"}}const r="config",l=()=>Object.fromEntries(p.map(e=>[e,d(e)])),v={notionAuth:null,notionToken:"",notionParentId:"",notionParentTitle:"",notionOAuthBackendUrl:"",ai:{mode:"direct",activeProvider:"openrouter",backendUrl:"",providers:l()},studyStyle:{...f},taskListSelector:"",duplicateStrategy:"ask",aiRequestsPerMinute:null};function S(e){var u;if(!e||typeof e!="object")return null;const t=n=>n&&(i(n)!==n||n===m);if(t(e.notionOAuthBackendUrl)&&(e={...e,notionOAuthBackendUrl:""}),t((u=e.ai)==null?void 0:u.backendUrl)&&(e={...e,ai:{...e.ai,backendUrl:""}}),e.ai&&e.ai.providers)return e;const a={...e},o=l();return(e.geminiApiKey||e.geminiModel)&&(o.gemini={apiKey:e.geminiApiKey||"",model:e.geminiModel||o.gemini.model,baseUrl:""}),a.ai={mode:e.aiProvider==="backend"?"backend":"direct",activeProvider:"gemini",backendUrl:i(e.backendUrl),providers:o},delete a.geminiApiKey,delete a.geminiModel,delete a.aiProvider,delete a.backendUrl,a}function h(e,t){const a={...e,...t};return t.studyStyle&&(a.studyStyle={...e.studyStyle,...t.studyStyle}),t.ai&&(a.ai={...e.ai,...t.ai,providers:{...e.ai.providers,...t.ai.providers||{}}}),a}async function g(){const e=await chrome.storage.local.get(r),t=S(e[r])||{},a=h(v,t);return a.ai.providers={...l(),...a.ai.providers},a}async function w(e){const t=h(await g(),e);return await chrome.storage.local.set({[r]:t}),t}async function I(e,t){const o=(await g()).ai.providers[e]||d(e);return w({ai:{providers:{[e]:{...o,...t}}}})}const N=e=>{var t;return((t=e==null?void 0:e.notionAuth)==null?void 0:t.accessToken)||(e==null?void 0:e.notionToken)||""},F=e=>{var t;return(t=e==null?void 0:e.notionAuth)!=null&&t.accessToken?"oauth":e!=null&&e.notionToken?"token":"none"},B=e=>e?e.length<=8?"••••••••":`${"•".repeat(12)}${e.slice(-4)}`:"",O=new RegExp("[\\u00AD\\u034F\\u061C\\u115F\\u1160\\u17B4\\u17B5\\u180B-\\u180E\\u200B-\\u200F\\u202A-\\u202E\\u2060-\\u2064\\u2066-\\u206F\\u3164\\uFE00-\\uFE0F\\uFEFF\\uFFA0]","g"),T=/[   -   　]/g;function x(e){return String(e??"").replace(O,"").replace(T," ").replace(/^["'\s]+|["'\s]+$/g,"")}function D(e){return x(e).replace(/\/+$/,"")}function A(e){return String(e??"").replace(/[^\x20-\x7E]/g,t=>`\\u${t.codePointAt(0).toString(16).toUpperCase().padStart(4,"0")}`)}const _=e=>String(e??"")!==A(e);export{v as D,U as I,s as P,i as a,m as b,x as c,A as d,d as e,D as f,g,_ as h,P as i,c as j,C as k,M as l,B as m,F as n,I as o,E as p,f as q,N as r,w as s};
